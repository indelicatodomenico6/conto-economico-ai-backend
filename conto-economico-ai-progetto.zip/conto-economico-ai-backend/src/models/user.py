from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from datetime import datetime

db = SQLAlchemy()
bcrypt = Bcrypt()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    business_name = db.Column(db.String(120))
    business_type = db.Column(db.String(50))
    subscription_plan = db.Column(db.String(20), default='free')
    stripe_customer_id = db.Column(db.String(100))
    subscription_status = db.Column(db.String(50), default='active')  # active, canceled, past_due
    subscription_end_date = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relazioni
    financial_data = db.relationship('FinancialData', backref='user', lazy=True, cascade='all, delete-orphan')
    subscription = db.relationship('Subscription', backref='user', lazy=True, uselist=False)

    def set_password(self, password):
        """Hash e salva la password"""
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def check_password(self, password):
        """Verifica la password"""
        return bcrypt.check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.email}>'

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'business_name': self.business_name,
            'business_type': self.business_type,
            'subscription_plan': self.subscription_plan,
            'subscription_status': self.subscription_status,
            'subscription_end_date': self.subscription_end_date.isoformat() if self.subscription_end_date else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class FinancialData(db.Model):
    __tablename__ = 'financial_data'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    month = db.Column(db.Integer, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    
    # Ricavi
    ricavi_servizi = db.Column(db.Numeric(10, 2), default=0)
    ricavi_prodotti = db.Column(db.Numeric(10, 2), default=0)
    altri_ricavi = db.Column(db.Numeric(10, 2), default=0)
    
    # Costi Variabili
    costo_merci = db.Column(db.Numeric(10, 2), default=0)
    provvigioni = db.Column(db.Numeric(10, 2), default=0)
    marketing_variabile = db.Column(db.Numeric(10, 2), default=0)
    
    # Costi Fissi
    affitto = db.Column(db.Numeric(10, 2), default=0)
    stipendi = db.Column(db.Numeric(10, 2), default=0)
    utenze = db.Column(db.Numeric(10, 2), default=0)
    marketing_fisso = db.Column(db.Numeric(10, 2), default=0)
    altri_costi_fissi = db.Column(db.Numeric(10, 2), default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Constraint per evitare duplicati
    __table_args__ = (db.UniqueConstraint('user_id', 'month', 'year', name='unique_user_month_year'),)

    @property
    def ricavi_totali(self):
        """Calcola i ricavi totali"""
        return float(self.ricavi_servizi or 0) + float(self.ricavi_prodotti or 0) + float(self.altri_ricavi or 0)

    @property
    def costi_variabili(self):
        """Calcola i costi variabili totali"""
        return float(self.costo_merci or 0) + float(self.provvigioni or 0) + float(self.marketing_variabile or 0)

    @property
    def costi_fissi(self):
        """Calcola i costi fissi totali"""
        return float(self.affitto or 0) + float(self.stipendi or 0) + float(self.utenze or 0) + float(self.marketing_fisso or 0) + float(self.altri_costi_fissi or 0)

    @property
    def totale_costi(self):
        """Calcola il totale dei costi"""
        return self.costi_variabili + self.costi_fissi

    @property
    def utile_netto(self):
        """Calcola l'utile netto"""
        return self.ricavi_totali - self.totale_costi

    @property
    def margine_percentuale(self):
        """Calcola il margine percentuale"""
        if self.ricavi_totali > 0:
            return (self.utile_netto / self.ricavi_totali) * 100
        return 0

    def __repr__(self):
        return f'<FinancialData {self.user_id} - {self.month}/{self.year}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'month': self.month,
            'year': self.year,
            'ricavi_servizi': float(self.ricavi_servizi or 0),
            'ricavi_prodotti': float(self.ricavi_prodotti or 0),
            'altri_ricavi': float(self.altri_ricavi or 0),
            'costo_merci': float(self.costo_merci or 0),
            'provvigioni': float(self.provvigioni or 0),
            'marketing_variabile': float(self.marketing_variabile or 0),
            'affitto': float(self.affitto or 0),
            'stipendi': float(self.stipendi or 0),
            'utenze': float(self.utenze or 0),
            'marketing_fisso': float(self.marketing_fisso or 0),
            'altri_costi_fissi': float(self.altri_costi_fissi or 0),
            'ricavi_totali': self.ricavi_totali,
            'costi_variabili': self.costi_variabili,
            'costi_fissi': self.costi_fissi,
            'totale_costi': self.totale_costi,
            'utile_netto': self.utile_netto,
            'margine_percentuale': round(self.margine_percentuale, 2),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Subscription(db.Model):
    __tablename__ = 'subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    stripe_subscription_id = db.Column(db.String(100))
    plan_name = db.Column(db.String(20), nullable=False, default='free')
    status = db.Column(db.String(20), nullable=False, default='active')
    current_period_start = db.Column(db.DateTime)
    current_period_end = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Subscription {self.user_id} - {self.plan_name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'stripe_subscription_id': self.stripe_subscription_id,
            'plan_name': self.plan_name,
            'status': self.status,
            'current_period_start': self.current_period_start.isoformat() if self.current_period_start else None,
            'current_period_end': self.current_period_end.isoformat() if self.current_period_end else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

